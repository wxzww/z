"""
主流水线 - 编排完整的分析→决策→风控→执行流程
每次K线收盘触发时执行一次完整流水线
"""
import json
import time
import threading
from datetime import datetime, timezone
from utils.logger import get_logger
from utils.config import AppConfig
from core.data_collector import DataCollector
from core.state_builder import StateBuilder
from core.strategy_engine import StrategyEngine
from core.risk_manager import RiskManager
from core.order_executor import OrderExecutor
from storage.database import Database
from notifications.telegram_notifier import TelegramNotifier

logger = get_logger("btc_trader.pipeline")


class TradingPipeline:
    """
    完整交易流水线
    调度器每15分钟/1小时/4小时触发一次run()
    """

    def __init__(self, config: AppConfig):
        self.config = config
        self.lock = threading.Lock()  # 防止并发执行

        # 初始化各模块
        self.data_collector = DataCollector(config)
        self.state_builder = StateBuilder(self.data_collector)
        self.strategy_engine = StrategyEngine(config)
        self.risk_manager = RiskManager(config.risk)
        self.order_executor = OrderExecutor(config, self.data_collector.client)
        self.db = Database(config.db_path)
        self.notifier = TelegramNotifier(config.telegram)

        logger.info("TradingPipeline初始化完成")

    def run(self, trigger: str):
        """
        执行一次完整分析流水线

        Args:
            trigger: 触发周期 "15m" / "1h" / "4h"
        """
        if not self.lock.acquire(blocking=False):
            logger.warning(f"上一次分析尚未完成，跳过本次 trigger={trigger}")
            return

        try:
            start = time.time()
            logger.info(f"========== 流水线启动 trigger={trigger} ==========")

            # Step 1: 检查风控状态
            self.risk_manager.check_cooldown_expired()
            if self.risk_manager.state.value in ("emergency", "consecutive_loss"):
                logger.warning(f"系统状态={self.risk_manager.state.value}，跳过分析")
                return

            # Step 2: 数据采集（预热缓存，确保各周期数据可用）
            logger.info("Step 2: 数据采集")
            if not self._collect_data(trigger):
                logger.error("数据采集失败，终止本次分析")
                return

            # Step 3: 同步交易所状态 + 组装state
            logger.info("Step 3: 状态同步与组装")
            state = self.state_builder.build(trigger)
            if not state:
                logger.error("状态组装失败，终止本次分析")
                return

            # Step 3.5: 前置检查 - 无止损持仓告警
            self._pre_check(state)

            # Step 4: 调用LLM决策
            logger.info("Step 4: 调用LLM策略分析")
            state_dict = state if isinstance(state, dict) else state.dict()
            decision = self.strategy_engine.analyze(state_dict)

            # Step 5: 风控校验
            logger.info("Step 5: 风控校验")
            positions_raw = state_dict.get("positions", [])
            orders_raw = state_dict.get("open_orders", [])
            account_raw = state_dict.get("account", {})
            current_price = state_dict.get("current_price", 0)

            safe_decision = self.risk_manager.validate_decision(
                decision, account_raw, positions_raw, orders_raw, current_price
            )

            # Step 6: 执行操作
            logger.info("Step 6: 执行操作")
            actions = safe_decision.get("actions", [])
            results = self.order_executor.execute_actions(actions, account_raw)

            # Step 7: 记录结果
            logger.info("Step 7: 记录与通知")
            self._record_decision(trigger, state_dict, decision, safe_decision, results)

            # Step 8: 通知
            self._send_notifications(trigger, safe_decision, results)

            # Step 9: 检查执行结果，更新风控状态
            self._post_execution_check(results)

            elapsed = time.time() - start
            logger.info(
                f"========== 流水线完成 trigger={trigger} "
                f"耗时={elapsed:.2f}s actions={len(results)} ==========\n"
            )

        except Exception as e:
            logger.error(f"流水线异常: {e}", exc_info=True)
            self.notifier.send_sync(f"🚨 流水线异常: {e}")

        finally:
            self.lock.release()

    def _collect_data(self, trigger: str) -> bool:
        """数据采集：拉取触发周期的新数据，其余用缓存。返回 True=成功"""
        try:
            for tf in self.config.strategy.timeframes:
                # 触发周期强制刷新；其余周期若缓存里有就跳过
                if tf == trigger or tf not in self.data_collector._cache:
                    df = self.data_collector.fetch_klines(tf)
                else:
                    df = self.data_collector._cache.get(tf)

                if df is None or len(df) < 60:
                    logger.warning(f"{tf} 数据不足，尝试强制刷新")
                    df = self.data_collector.fetch_klines(tf)
                    if df is None or len(df) < 60:
                        logger.error(f"{tf} 数据采集失败")
                        return False
            return True
        except Exception as e:
            logger.error(f"数据采集异常: {e}")
            return False

    def _pre_check(self, state):
        """前置检查：有持仓但没有止损单的情况"""
        state_dict = state if isinstance(state, dict) else state.dict()
        positions = state_dict.get("positions", [])
        orders = state_dict.get("open_orders", [])

        if positions:
            has_stop = any(
                o.get("order_type") == "STOP_MARKET" or o.get("purpose") == "stop_loss"
                for o in orders
            )
            if not has_stop:
                logger.critical("⚠️ 有持仓但没有止损单！")
                # 在state的notes里添加提醒，Claude会优先补挂止损
                if isinstance(state, dict):
                    state.setdefault("notes", []).append(
                        "CRITICAL: 当前有持仓但没有止损单，请立即补挂止损！"
                    )
                # 也可以在这里直接自动挂一个宽止损
                self._emergency_stop_loss(positions, state_dict.get("current_price", 0))

    def _emergency_stop_loss(self, positions: list, current_price: float):
        """紧急补挂宽止损（入场价±5%）"""
        if not current_price or current_price <= 0:
            return
        for pos in positions:
            try:
                entry = pos.get("entry_price", current_price)
                qty = abs(pos.get("quantity", 0))
                if qty <= 0:
                    continue

                pct = self.config.risk.emergency_stop_loss_pct
                if pos.get("side") == "long":
                    stop_price = round(entry * (1 - pct), 2)
                    self.order_executor._place_stop_order(
                        "SELL", stop_price, qty, "紧急补挂止损(多)"
                    )
                else:
                    stop_price = round(entry * (1 + pct), 2)
                    self.order_executor._place_stop_order(
                        "BUY", stop_price, qty, "紧急补挂止损(空)"
                    )
                logger.critical(f"紧急止损已挂: stop={stop_price}, qty={qty}")
            except Exception as e:
                logger.error(f"紧急止损挂单失败: {e}")

    def _record_decision(self, trigger: str, state_dict: dict,
                         raw_decision: dict, safe_decision: dict,
                         results: list):
        """记录决策到数据库"""
        try:
            # 计算被过滤的action
            raw_actions = set(
                a.get("action", "") for a in raw_decision.get("actions", [])
            )
            safe_actions = set(
                a.get("action", "") for a in safe_decision.get("actions", [])
            )
            filtered = raw_actions - safe_actions

            self.db.insert_decision(
                trigger=trigger,
                input_json=json.dumps(state_dict, ensure_ascii=False, default=str),
                output_json=json.dumps(raw_decision, ensure_ascii=False, default=str),
                actions_executed=json.dumps(
                    [r for r in results if r.get("status") == "success"],
                    ensure_ascii=False, default=str
                ),
                risk_filtered=json.dumps(list(filtered), ensure_ascii=False),
            )

            # 记录每笔实际执行的交易
            for result in results:
                if result.get("status") == "success" and result.get("action") in (
                    "open_long", "open_short", "close_long", "close_short",
                    "add_position", "reduce_position"
                ):
                    self.db.insert_trade(
                        symbol=self.config.binance.symbol,
                        side=result.get("action", ""),
                        action=result.get("action", ""),
                        price=result.get("price", 0),
                        quantity=result.get("quantity", 0),
                        reason=next(
                            (a.get("reason", "") for a in safe_decision.get("actions", [])
                             if a.get("action") == result.get("action")),
                            ""
                        ),
                        confidence=safe_decision.get("analysis", {}).get("confidence", 0),
                    )
        except Exception as e:
            logger.error(f"记录决策失败: {e}")

    def _send_notifications(self, trigger: str, decision: dict, results: list):
        """发送通知"""
        try:
            # 只在有实际交易操作时发送通知
            executed = [
                r for r in results
                if r.get("status") == "success" and r.get("action") not in (
                    "hold", "no_action"
                )
            ]

            if not executed:
                return

            analysis = decision.get("analysis", {})
            msg_parts = [
                f"📊 {trigger.upper()} 分析完成",
                f"方向: {analysis.get('direction', 'N/A')}",
                f"信心: {'⭐' * analysis.get('confidence', 0)}",
                f"逻辑: {analysis.get('reasoning', '')}",
                "",
            ]

            for r in executed:
                msg_parts.append(f"✅ {r.get('action')}: {r.get('status')}")
                if r.get("quantity"):
                    msg_parts.append(f"   数量: {r['quantity']} BTC")
                if r.get("price"):
                    msg_parts.append(f"   价格: {r['price']}")

            warnings = decision.get("risk_warnings", [])
            if warnings:
                msg_parts.append("")
                for w in warnings:
                    msg_parts.append(f"⚠️ {w}")

            self.notifier.send_sync("\n".join(msg_parts))

        except Exception as e:
            logger.error(f"发送通知失败: {e}")

    def _post_execution_check(self, results: list):
        """执行后检查：更新风控状态"""
        for result in results:
            action = result.get("action", "")
            status = result.get("status", "")

            # 检查是否有止损被触发（通过对比前后持仓变化）
            # 这里简化处理，实际应该通过订单状态查询
            if action in ("close_long", "close_short") and status == "success":
                pnl = result.get("pnl")
                if pnl is not None:
                    if pnl < 0:
                        self.risk_manager.record_stop_loss(pnl)
                    else:
                        self.risk_manager.record_profit(pnl)

    # ============================================================
    # 对外接口
    # ============================================================

    def startup(self):
        """系统启动初始化"""
        logger.info("系统启动中...")

        # 1. 测试连接
        logger.info("测试Binance连接...")
        try:
            self.data_collector.client.futures_ping()
            logger.info("Binance连接正常")
        except Exception as e:
            raise RuntimeError(f"Binance连接失败: {e}")

        logger.info("测试 LLM API 连接 (OpenRouter)...")
        if not self.strategy_engine.ping():
            raise RuntimeError("LLM API 连接失败")
        logger.info("LLM API 连接正常")

        # 2. 同步交易所设置
        try:
            self.data_collector.client.futures_change_leverage(
                symbol=self.config.binance.symbol,
                leverage=self.config.binance.leverage
            )
            logger.info(f"杠杆设置: {self.config.binance.leverage}x")

            self.data_collector.client.futures_change_margin_type(
                symbol=self.config.binance.symbol,
                marginType=self.config.binance.margin_type
            )
            logger.info(f"保证金模式: {self.config.binance.margin_type}")
        except Exception as e:
            # 杠杆或保证金模式可能已经是目标值，忽略错误
            logger.warning(f"设置杠杆/保证金模式: {e}")

        # 3. 初始化数据库
        self.db.initialize()
        logger.info("数据库初始化完成")

        # 4. 执行一次全周期分析
        logger.info("执行初始全周期分析...")
        for tf in ["4h", "1h", "15m"]:
            self.run(tf)

        self.notifier.send_sync(
            f"✅ 系统启动成功\n"
            f"品种: {self.config.binance.symbol}\n"
            f"杠杆: {self.config.binance.leverage}x\n"
            f"模式: {'测试网' if self.config.binance.testnet else '主网'}"
        )
        logger.info("系统启动完成")

    def shutdown(self, reason: str = "manual"):
        """优雅关闭"""
        logger.info(f"系统关闭: {reason}")
        self.notifier.send_sync(f"⏸️ 系统关闭: {reason}")

    def emergency_stop(self, reason: str):
        """紧急停止"""
        logger.critical(f"紧急停止: {reason}")
        self.risk_manager.trigger_emergency(reason)
        self.order_executor.emergency_cancel_all()
        self.notifier.send_sync(f"🚨 紧急停止: {reason}\n所有挂单已撤销")
