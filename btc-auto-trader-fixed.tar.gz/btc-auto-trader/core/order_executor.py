"""
订单执行模块 - 将Claude的决策指令转化为Binance API调用
谨记：每次开仓都必须挂止损和止盈
"""
import time
from binance.client import Client
from binance.exceptions import BinanceAPIException
from utils.logger import get_logger
from utils.config import AppConfig

logger = get_logger("btc_trader.executor")

# 执行优先级顺序
ACTION_PRIORITY = {
    "cancel_all": 0,
    "cancel_order": 1,
    "close_long": 2,
    "close_short": 2,
    "reduce_position": 3,
    "move_stop_loss": 4,
    "move_take_profit": 4,
    "open_long": 5,
    "open_short": 5,
    "add_position": 5,
    "place_limit_entry": 5,
    "place_stop_loss": 6,
    "place_take_profit": 6,
    "replace_order": 7,
    "hold": 99,
    "no_action": 99,
}


class OrderExecutor:
    """
    订单执行器 - 解析action列表并按优先级顺序执行
    核心原则：开仓必挂止损+止盈
    """

    def __init__(self, config: AppConfig, binance_client: Client):
        self.config = config
        self.client = binance_client
        self.symbol = config.binance.symbol
        self.leverage = config.binance.leverage

    def execute_actions(self, actions: list, account: dict) -> list[dict]:
        """
        按优先级顺序执行所有actions

        Returns:
            每个action的执行结果列表
        """
        if not actions:
            return []

        # 按优先级排序
        sorted_actions = sorted(
            actions,
            key=lambda a: ACTION_PRIORITY.get(a.get("action", ""), 50)
        )

        results = []
        for action in sorted_actions:
            act_type = action.get("action", "")

            if act_type in ("hold", "no_action"):
                results.append({"action": act_type, "status": "skipped", "reason": action.get("reason", "")})
                continue

            try:
                result = self._dispatch(action, act_type, account)
                results.append(result)
                logger.info(f"执行成功: {act_type} → {result.get('status')}")
            except BinanceAPIException as e:
                error_result = {
                    "action": act_type,
                    "status": "failed",
                    "error": str(e),
                    "error_code": e.code if hasattr(e, 'code') else None,
                }
                results.append(error_result)
                logger.error(f"执行失败: {act_type} → {e}")

                # 关键操作失败时停止后续
                if act_type in ("close_long", "close_short") and \
                   any(a.get("action") in ("open_long", "open_short") for a in sorted_actions):
                    logger.error("平仓失败，取消后续开仓操作")
                    break

            except Exception as e:
                results.append({"action": act_type, "status": "error", "error": str(e)})
                logger.error(f"执行异常: {act_type} → {e}")

        return results

    def _dispatch(self, action: dict, act_type: str, account: dict) -> dict:
        """分发到对应的执行方法"""
        handlers = {
            "open_long": self._open_long,
            "open_short": self._open_short,
            "close_long": self._close_position,
            "close_short": self._close_position,
            "add_position": self._add_position,
            "reduce_position": self._reduce_position,
            "place_stop_loss": self._place_stop_loss,
            "place_take_profit": self._place_take_profit,
            "move_stop_loss": self._move_stop_loss,
            "move_take_profit": self._move_take_profit,
            "place_limit_entry": self._place_limit_entry,
            "cancel_order": self._cancel_order,
            "cancel_all": self._cancel_all,
            "replace_order": self._replace_order,
        }
        handler = handlers.get(act_type)
        if not handler:
            return {"action": act_type, "status": "unknown_action"}
        return handler(action, account)

    # ============================================================
    # 开仓 - 每次开仓都必须带止损+止盈
    # ============================================================

    def _open_long(self, action: dict, account: dict) -> dict:
        """开多仓 + 自动挂止损 + 自动挂止盈"""
        quantity = self._calc_quantity(action, account)
        order_type = action.get("order_type", "market")

        # 第一步：开仓
        if order_type == "market":
            order = self.client.futures_create_order(
                symbol=self.symbol, side="BUY",
                type="MARKET", quantity=quantity
            )
        else:
            price = action["price"]
            order = self.client.futures_create_order(
                symbol=self.symbol, side="BUY",
                type="LIMIT", price=str(price),
                quantity=quantity, timeInForce="GTC"
            )

        logger.info(f"开多仓: qty={quantity}, order_id={order['orderId']}")

        # 第二步：挂止损（必须）
        sl_order = self._place_stop_order(
            side="SELL",
            stop_price=action["stop_loss_price"],
            quantity=quantity,
            purpose="开多止损"
        )

        # 第三步：挂止盈（必须）
        tp_order = self._place_tp_order(
            side="SELL",
            price=action["take_profit_price"],
            quantity=quantity,
            purpose="开多止盈"
        )

        # 第四步：如果有第二止盈
        tp2_order = None
        if action.get("take_profit_2_price"):
            # 第二止盈用一半数量
            tp2_qty = self._round_quantity(quantity / 2)
            if tp2_qty > 0:
                tp2_order = self._place_tp_order(
                    side="SELL",
                    price=action["take_profit_2_price"],
                    quantity=tp2_qty,
                    purpose="开多止盈2"
                )

        return {
            "action": "open_long",
            "status": "success",
            "order_id": str(order["orderId"]),
            "quantity": quantity,
            "price": float(order.get("avgPrice", 0)) or action.get("price"),
            "stop_loss_order": sl_order.get("orderId") if sl_order else None,
            "take_profit_order": tp_order.get("orderId") if tp_order else None,
        }

    def _open_short(self, action: dict, account: dict) -> dict:
        """开空仓 + 自动挂止损 + 自动挂止盈"""
        quantity = self._calc_quantity(action, account)
        order_type = action.get("order_type", "market")

        if order_type == "market":
            order = self.client.futures_create_order(
                symbol=self.symbol, side="SELL",
                type="MARKET", quantity=quantity
            )
        else:
            price = action["price"]
            order = self.client.futures_create_order(
                symbol=self.symbol, side="SELL",
                type="LIMIT", price=str(price),
                quantity=quantity, timeInForce="GTC"
            )

        logger.info(f"开空仓: qty={quantity}, order_id={order['orderId']}")

        # 止损（买入止损）
        sl_order = self._place_stop_order(
            side="BUY",
            stop_price=action["stop_loss_price"],
            quantity=quantity,
            purpose="开空止损"
        )

        # 止盈（限价买入）
        tp_order = self._place_tp_order(
            side="BUY",
            price=action["take_profit_price"],
            quantity=quantity,
            purpose="开空止盈"
        )

        tp2_order = None
        if action.get("take_profit_2_price"):
            tp2_qty = self._round_quantity(quantity / 2)
            if tp2_qty > 0:
                tp2_order = self._place_tp_order(
                    side="BUY",
                    price=action["take_profit_2_price"],
                    quantity=tp2_qty,
                    purpose="开空止盈2"
                )

        return {
            "action": "open_short",
            "status": "success",
            "order_id": str(order["orderId"]),
            "quantity": quantity,
            "stop_loss_order": sl_order.get("orderId") if sl_order else None,
            "take_profit_order": tp_order.get("orderId") if tp_order else None,
        }

    # ============================================================
    # 平仓/减仓
    # ============================================================

    def _close_position(self, action: dict, account: dict) -> dict:
        """平仓（全平或部分平）"""
        act_type = action.get("action")
        side = "SELL" if act_type == "close_long" else "BUY"

        # 获取当前持仓数量
        positions = self.client.futures_position_information(symbol=self.symbol)
        pos_qty = 0
        for p in positions:
            amt = float(p["positionAmt"])
            if amt != 0:
                pos_qty = abs(amt)
                break

        if pos_qty == 0:
            logger.warning("平仓指令但无持仓")
            return {"action": act_type, "status": "no_position"}

        # 计算平仓数量
        qty_pct = action.get("quantity_pct", 1.0)
        close_qty = self._round_quantity(pos_qty * qty_pct)
        if close_qty <= 0:
            close_qty = pos_qty  # 至少平最小单位

        order = self.client.futures_create_order(
            symbol=self.symbol, side=side,
            type="MARKET", quantity=close_qty,
            reduceOnly=True
        )

        logger.info(f"平仓: side={side}, qty={close_qty}, order_id={order['orderId']}")

        # 如果全平，撤销所有关联挂单
        if qty_pct >= 0.99:
            self._cleanup_orphan_orders()

        # 如果部分平仓，需要调整止损/止盈数量
        elif qty_pct < 0.99:
            remaining = self._round_quantity(pos_qty - close_qty)
            if remaining > 0:
                self._adjust_protective_orders(side, remaining)

        return {
            "action": act_type,
            "status": "success",
            "order_id": str(order["orderId"]),
            "quantity": close_qty,
        }

    def _reduce_position(self, action: dict, account: dict) -> dict:
        """减仓（等同于部分平仓）"""
        # 判断当前持仓方向
        positions = self.client.futures_position_information(symbol=self.symbol)
        for p in positions:
            amt = float(p["positionAmt"])
            if amt > 0:
                action["action"] = "close_long"
            elif amt < 0:
                action["action"] = "close_short"
            else:
                return {"action": "reduce_position", "status": "no_position"}
        return self._close_position(action, account)

    def _add_position(self, action: dict, account: dict) -> dict:
        """加仓（同方向追加）- 同样必须带止损止盈"""
        # 判断当前持仓方向
        positions = self.client.futures_position_information(symbol=self.symbol)
        for p in positions:
            amt = float(p["positionAmt"])
            if amt > 0:
                return self._open_long(action, account)
            elif amt < 0:
                return self._open_short(action, account)
        # 无持仓当作新开仓
        side = action.get("side", "buy")
        if side == "buy":
            return self._open_long(action, account)
        return self._open_short(action, account)

    # ============================================================
    # 止损止盈管理
    # ============================================================

    def _place_stop_order(self, side: str, stop_price: float,
                          quantity: float, purpose: str = "") -> dict:
        """挂止损单"""
        try:
            order = self.client.futures_create_order(
                symbol=self.symbol,
                side=side,
                type="STOP_MARKET",
                stopPrice=str(round(stop_price, 2)),
                quantity=quantity,
                reduceOnly=True,
                workingType="MARK_PRICE",
            )
            logger.info(f"挂止损: {purpose}, price={stop_price}, qty={quantity}, id={order['orderId']}")
            return order
        except BinanceAPIException as e:
            logger.error(f"挂止损失败: {purpose}, {e}")
            return {}

    def _place_tp_order(self, side: str, price: float,
                        quantity: float, purpose: str = "") -> dict:
        """挂止盈单"""
        try:
            order = self.client.futures_create_order(
                symbol=self.symbol,
                side=side,
                type="TAKE_PROFIT_MARKET",
                stopPrice=str(round(price, 2)),
                quantity=quantity,
                reduceOnly=True,
                workingType="MARK_PRICE",
            )
            logger.info(f"挂止盈: {purpose}, price={price}, qty={quantity}, id={order['orderId']}")
            return order
        except BinanceAPIException as e:
            logger.error(f"挂止盈失败: {purpose}, {e}")
            return {}

    def _place_stop_loss(self, action: dict, account: dict) -> dict:
        """单独挂止损"""
        positions = self.client.futures_position_information(symbol=self.symbol)
        for p in positions:
            amt = float(p["positionAmt"])
            if amt > 0:
                order = self._place_stop_order("SELL", action["price"], abs(amt), "补挂止损")
                return {"action": "place_stop_loss", "status": "success", "order": order}
            elif amt < 0:
                order = self._place_stop_order("BUY", action["price"], abs(amt), "补挂止损")
                return {"action": "place_stop_loss", "status": "success", "order": order}
        return {"action": "place_stop_loss", "status": "no_position"}

    def _place_take_profit(self, action: dict, account: dict) -> dict:
        """单独挂止盈"""
        positions = self.client.futures_position_information(symbol=self.symbol)
        for p in positions:
            amt = float(p["positionAmt"])
            qty = action.get("quantity", abs(amt))
            if amt > 0:
                order = self._place_tp_order("SELL", action["price"], qty, "补挂止盈")
                return {"action": "place_take_profit", "status": "success", "order": order}
            elif amt < 0:
                order = self._place_tp_order("BUY", action["price"], qty, "补挂止盈")
                return {"action": "place_take_profit", "status": "success", "order": order}
        return {"action": "place_take_profit", "status": "no_position"}

    def _move_stop_loss(self, action: dict, account: dict) -> dict:
        """移动止损：撤旧→挂新"""
        new_price = action.get("new_stop_price")
        if not new_price:
            return {"action": "move_stop_loss", "status": "missing_price"}

        # 1. 找到现有止损单
        orders = self.client.futures_get_open_orders(symbol=self.symbol)
        old_stops = [o for o in orders if o["type"] == "STOP_MARKET"]

        # 2. 撤旧
        for stop in old_stops:
            try:
                self.client.futures_cancel_order(
                    symbol=self.symbol, orderId=stop["orderId"]
                )
                logger.info(f"撤销旧止损: {stop['orderId']}")
            except BinanceAPIException as e:
                logger.error(f"撤旧止损失败: {e}")
                return {"action": "move_stop_loss", "status": "cancel_failed", "error": str(e)}

        # 3. 挂新
        positions = self.client.futures_position_information(symbol=self.symbol)
        for p in positions:
            amt = float(p["positionAmt"])
            if amt > 0:
                order = self._place_stop_order("SELL", new_price, abs(amt), f"移动止损→{new_price}")
                return {"action": "move_stop_loss", "status": "success", "new_price": new_price}
            elif amt < 0:
                order = self._place_stop_order("BUY", new_price, abs(amt), f"移动止损→{new_price}")
                return {"action": "move_stop_loss", "status": "success", "new_price": new_price}

        return {"action": "move_stop_loss", "status": "no_position"}

    def _move_take_profit(self, action: dict, account: dict) -> dict:
        """移动止盈：撤旧→挂新"""
        new_price = action.get("new_tp_price")
        if not new_price:
            return {"action": "move_take_profit", "status": "missing_price"}

        orders = self.client.futures_get_open_orders(symbol=self.symbol)
        old_tps = [o for o in orders if o["type"] == "TAKE_PROFIT_MARKET"]

        for tp in old_tps:
            try:
                self.client.futures_cancel_order(symbol=self.symbol, orderId=tp["orderId"])
            except BinanceAPIException:
                pass

        positions = self.client.futures_position_information(symbol=self.symbol)
        for p in positions:
            amt = float(p["positionAmt"])
            if amt > 0:
                self._place_tp_order("SELL", new_price, abs(amt), f"移动止盈→{new_price}")
            elif amt < 0:
                self._place_tp_order("BUY", new_price, abs(amt), f"移动止盈→{new_price}")

        return {"action": "move_take_profit", "status": "success", "new_price": new_price}

    # ============================================================
    # 挂单管理
    # ============================================================

    def _place_limit_entry(self, action: dict, account: dict) -> dict:
        """挂限价入场单 + 预设止损止盈"""
        quantity = self._calc_quantity(action, account)
        side = "BUY" if action.get("side", "buy") == "buy" else "SELL"

        order = self.client.futures_create_order(
            symbol=self.symbol, side=side,
            type="LIMIT", price=str(action["price"]),
            quantity=quantity, timeInForce="GTC"
        )

        logger.info(f"挂限价入场单: side={side}, price={action['price']}, qty={quantity}")

        # 注意：限价入场单的止损止盈需要在成交后挂
        # 这里先记录，由pipeline在下次分析时检查是否成交
        return {
            "action": "place_limit_entry",
            "status": "success",
            "order_id": str(order["orderId"]),
            "quantity": quantity,
            "pending_stop_loss": action["stop_loss_price"],
            "pending_take_profit": action["take_profit_price"],
        }

    def _cancel_order(self, action: dict, account: dict) -> dict:
        """撤销指定挂单"""
        order_id = action.get("cancel_order_id")
        if not order_id:
            return {"action": "cancel_order", "status": "missing_order_id"}

        try:
            self.client.futures_cancel_order(
                symbol=self.symbol, orderId=int(order_id)
            )
            logger.info(f"撤单成功: {order_id}")
            return {"action": "cancel_order", "status": "success", "order_id": order_id}
        except BinanceAPIException as e:
            if "Unknown order" in str(e):
                logger.warning(f"订单已不存在: {order_id}")
                return {"action": "cancel_order", "status": "already_gone"}
            raise

    def _cancel_all(self, action: dict, account: dict) -> dict:
        """撤销所有挂单"""
        try:
            self.client.futures_cancel_all_open_orders(symbol=self.symbol)
            logger.info("撤销所有挂单")
            return {"action": "cancel_all", "status": "success"}
        except BinanceAPIException as e:
            logger.error(f"撤销所有挂单失败: {e}")
            raise

    def _replace_order(self, action: dict, account: dict) -> dict:
        """替换挂单（撤旧+挂新）"""
        # 先撤
        cancel_result = self._cancel_order(action, account)
        if cancel_result["status"] not in ("success", "already_gone"):
            return cancel_result

        # 再挂新的限价单
        side = action.get("side", "buy")
        quantity = self._calc_quantity(action, account) if action.get("quantity_pct") else action.get("quantity", 0)

        order = self.client.futures_create_order(
            symbol=self.symbol,
            side=side.upper(),
            type="LIMIT",
            price=str(action["price"]),
            quantity=quantity,
            timeInForce="GTC"
        )
        return {"action": "replace_order", "status": "success", "new_order_id": str(order["orderId"])}

    # ============================================================
    # 辅助方法
    # ============================================================

    def _calc_quantity(self, action: dict, account: dict) -> float:
        """将资金百分比转换为BTC数量"""
        pct = action.get("quantity_pct", 0.10)
        total = account.get("total_balance", 0)
        price = action.get("price") or self._get_price()
        if price <= 0:
            raise ValueError("无法获取价格")

        usdt_amount = total * pct
        btc_qty = usdt_amount * self.leverage / price
        return self._round_quantity(btc_qty)

    def _round_quantity(self, qty: float) -> float:
        """BTC精度：最小0.001"""
        return round(max(qty, 0), 3)

    def _get_price(self) -> float:
        """获取当前价格"""
        ticker = self.client.futures_symbol_ticker(symbol=self.symbol)
        return float(ticker["price"])

    def _cleanup_orphan_orders(self):
        """清理孤儿订单（全平后撤销所有关联挂单）"""
        try:
            orders = self.client.futures_get_open_orders(symbol=self.symbol)
            for o in orders:
                if o["type"] in ("STOP_MARKET", "TAKE_PROFIT_MARKET"):
                    try:
                        self.client.futures_cancel_order(
                            symbol=self.symbol, orderId=o["orderId"]
                        )
                        logger.info(f"清理孤儿单: {o['orderId']} ({o['type']})")
                    except Exception:
                        pass
        except Exception as e:
            logger.warning(f"清理孤儿单失败: {e}")

    def _adjust_protective_orders(self, close_side: str, remaining_qty: float):
        """减仓后调整止损止盈数量"""
        try:
            orders = self.client.futures_get_open_orders(symbol=self.symbol)
            for o in orders:
                if o["type"] in ("STOP_MARKET", "TAKE_PROFIT_MARKET"):
                    old_qty = float(o["origQty"])
                    if old_qty > remaining_qty * 1.01:
                        # 撤旧挂新
                        self.client.futures_cancel_order(
                            symbol=self.symbol, orderId=o["orderId"]
                        )
                        stop_price = float(o.get("stopPrice", 0))
                        if stop_price > 0:
                            if o["type"] == "STOP_MARKET":
                                self._place_stop_order(
                                    o["side"], stop_price,
                                    remaining_qty, "减仓后调整止损"
                                )
                            else:
                                self._place_tp_order(
                                    o["side"], stop_price,
                                    remaining_qty, "减仓后调整止盈"
                                )
        except Exception as e:
            logger.warning(f"调整保护单失败: {e}")

    def emergency_cancel_all(self):
        """紧急撤销所有挂单"""
        try:
            self.client.futures_cancel_all_open_orders(symbol=self.symbol)
            logger.critical("紧急撤销所有挂单完成")
        except Exception as e:
            logger.critical(f"紧急撤单失败: {e}")
