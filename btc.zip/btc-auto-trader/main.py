"""
BTC自动化交易系统 - 主入口
基于「两点一线」双均线策略 + Claude API决策引擎

使用方法:
    python main.py                  # 正常启动
    python main.py --test           # 单次测试运行（不启动调度）
    python main.py --config path    # 指定配置文件路径
"""
import sys
import signal
import argparse
import time
from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.cron import CronTrigger
from utils.config import load_config
from utils.logger import setup_logger, get_logger
from core.pipeline import TradingPipeline

logger = get_logger("btc_trader.main")


def create_scheduler(pipeline: TradingPipeline) -> BlockingScheduler:
    """
    创建定时调度器

    调度规则（UTC时间）:
    - 4H K线收盘: 00:00,04:00,08:00,12:00,16:00,20:00 +3s
    - 1H K线收盘: 每小时:00 +8s
    - 15M K线收盘: :00,:15,:30,:45 +13s

    1H 和 15M 的 cron job 始终注册，但 pipeline.run() 内部会根据
    LLM 的 next_analysis 建议决定是否真正执行（_should_run 检查）。
    横盘无持仓时 LLM 会关闭小周期，这些 job 触发后直接跳过。
    """
    scheduler = BlockingScheduler(timezone="UTC")

    # 4H — 永远执行，安全底线（每天6次）
    scheduler.add_job(
        pipeline.run,
        CronTrigger(hour="0,4,8,12,16,20", minute=0, second=3),
        args=["4h"],
        id="analysis_4h",
        name="4H分析",
        misfire_grace_time=60,
        max_instances=1,
    )

    # 1H — 由 LLM next_analysis.monitor_1h 控制是否实际执行
    scheduler.add_job(
        pipeline.run,
        CronTrigger(minute=0, second=8),
        args=["1h"],
        id="analysis_1h",
        name="1H分析",
        misfire_grace_time=60,
        max_instances=1,
    )

    # 15M — 由 LLM next_analysis.monitor_15m 控制是否实际执行
    scheduler.add_job(
        pipeline.run,
        CronTrigger(minute="0,15,30,45", second=13),
        args=["15m"],
        id="analysis_15m",
        name="15M分析",
        misfire_grace_time=60,
        max_instances=1,
    )

    # 每日报告 - UTC 00:00
    scheduler.add_job(
        _daily_report,
        CronTrigger(hour=0, minute=1),
        args=[pipeline],
        id="daily_report",
        name="每日报告",
    )

    # 健康检查 - 每5分钟
    scheduler.add_job(
        _health_check,
        "interval",
        minutes=5,
        args=[pipeline],
        id="health_check",
        name="健康检查",
    )

    return scheduler


def _daily_report(pipeline: TradingPipeline):
    """生成并发送每日报告"""
    try:
        stats = pipeline.db.get_daily_stats()
        account = pipeline.data_collector.client.futures_account_balance()
        balance = sum(float(a["balance"]) for a in account if a["asset"] == "USDT")
        pipeline.notifier.send_daily_report(stats, balance)
    except Exception as e:
        logger.error(f"生成日报失败: {e}")


def _health_check(pipeline: TradingPipeline):
    """健康检查"""
    try:
        pipeline.data_collector.client.futures_ping()
    except Exception as e:
        logger.error(f"健康检查: Binance连接异常 - {e}")
        pipeline.notifier.send_sync(f"⚠️ 健康检查: Binance连接异常")


def main():
    parser = argparse.ArgumentParser(description="BTC自动化交易系统")
    parser.add_argument("--config", default="config.yaml", help="配置文件路径")
    parser.add_argument("--test", action="store_true", help="单次测试运行")
    args = parser.parse_args()

    # 1. 加载配置
    config = load_config(args.config)
    setup_logger(config.log_level, config.log_file)
    logger.info("=" * 60)
    logger.info("BTC自动化交易系统启动")
    logger.info(f"配置: {args.config}")
    logger.info(f"模式: {'测试网' if config.binance.testnet else '⚠️ 主网'}")
    logger.info(f"品种: {config.binance.symbol}")
    logger.info(f"杠杆: {config.binance.leverage}x")
    logger.info("=" * 60)

    # 2. 初始化Pipeline
    pipeline = TradingPipeline(config)

    # 3. 信号处理（优雅关闭）
    def handle_signal(signum, frame):
        logger.info(f"收到信号 {signum}，正在关闭...")
        pipeline.shutdown(f"signal_{signum}")
        sys.exit(0)

    signal.signal(signal.SIGINT, handle_signal)
    signal.signal(signal.SIGTERM, handle_signal)

    # 4. 启动
    try:
        pipeline.startup()

        if args.test:
            logger.info("测试模式：执行一次15M分析后退出")
            pipeline.run("15m")
            logger.info("测试完成")
            return

        # 5. 启动调度器（阻塞运行）
        scheduler = create_scheduler(pipeline)

        logger.info("调度器启动，等待K线收盘触发...")
        logger.info("调度任务:")
        for job in scheduler.get_jobs():
            logger.info(f"  {job.name}: {job.trigger}")

        scheduler.start()

    except KeyboardInterrupt:
        logger.info("用户中断")
        pipeline.shutdown("keyboard_interrupt")
    except Exception as e:
        logger.critical(f"系统异常: {e}", exc_info=True)
        pipeline.emergency_stop(str(e))
        sys.exit(1)


if __name__ == "__main__":
    main()